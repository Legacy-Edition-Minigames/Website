Brand asset guidelines:
=======================
You are **NOT** allowed to use these assets in refrence to a project other than LEM.
You are **NOT** allowed to use these assets for your own minigame projects.
You are **NOT** allowed to use these assets in refrence to the original Mini games.

You are allowed to use these assets in thumbnails, videos, or print, *in refrence to LEM.*
